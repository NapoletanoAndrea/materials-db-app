import LoginForm from "./LoginForm";

export default function LoginPage() {
  return (
    <section>
      <div className="container">
        <LoginForm />
      </div>
    </section>
  );
}
