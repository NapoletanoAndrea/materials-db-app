import RegistrationForm from "./RegistrationForm";

export default function RegistrationPage() {
  return (
    <section>
      <div className="container">
        <RegistrationForm />
      </div>
    </section>
  );
}
