import LoadingSpinner from "../features/loading/LoadingSpinner";

export default function TestPage() {
  return (
    <>
      <LoadingSpinner />
    </>
  );
}
