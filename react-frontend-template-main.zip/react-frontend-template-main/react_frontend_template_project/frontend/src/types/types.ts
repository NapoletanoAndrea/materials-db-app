export interface KeyStringObject {
    [key: string]: any;
}